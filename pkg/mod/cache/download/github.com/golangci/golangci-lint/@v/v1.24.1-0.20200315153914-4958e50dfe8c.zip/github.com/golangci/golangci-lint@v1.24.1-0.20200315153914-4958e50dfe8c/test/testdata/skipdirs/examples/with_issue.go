package main

import "fmt"

func main() {
	if true {
		return
	} else {
		fmt.Printf("")
	}
}
